setTimeout(function(){// wait for 5 secs(2)
           		location.reload(); // then reload the page.(3)
      			}, 3000);