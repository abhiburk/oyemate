<!--Relative Path-->
<link rel="stylesheet" type="text/css" href="assets/font/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="assets/font.css" />
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" media="screen" />
<link rel="stylesheet" type="text/css" href="assets/css/style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="assets/css/responsive.css" media="screen" />
<link rel="stylesheet" type="text/css" href="assets/css/jquery.bxslider.css" media="screen" />
<script type="text/javascript" src="assets/js/jquery-min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.bxslider.js"></script>
<script type="text/javascript" src="assets/js/selectnav.min.js"></script>
<link rel="stylesheet" href="assets/js/bootstrap-fileupload.min.css" />
<script src="assets/js/bootstrap-fileupload.js"></script>
<link rel="stylesheet" href="assets/css/jquery-ui.css">
<script src="assets/css/jquery-ui.js"></script>
<!--<script src="assets/js/jquery.bootpag.min.js"></script>
<script src="assets/js/jquery.1.12.0.min.js"></script>-->




<!--Absolute Path-->
<!--<link rel="stylesheet" type="text/css" href="//localhost/skymate/web/assets/font/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="//localhost/skymate/web/assets/font.css" />
<link rel="stylesheet" type="text/css" href="//localhost/skymate/web/assets/css/bootstrap.min.css" media="screen" />
<link rel="stylesheet" type="text/css" href="http://localhost/skymate/web/assets/css/style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="//localhost/skymate/web/assets/css/responsive.css" media="screen" />
<link rel="stylesheet" type="text/css" href="//localhost/skymate/web/assets/css/jquery.bxslider.css" media="screen" />
<script type="text/javascript" src="//localhost/skymate/web/assets/js/jquery-min.js"></script>
<script type="text/javascript" src="//localhost/skymate/web/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="//localhost/skymate/web/assets/js/jquery.bxslider.js"></script>
<script type="text/javascript" src="//localhost/skymate/web/assets/js/selectnav.min.js"></script>
<link rel="stylesheet" href="//localhost/skymate/web/assets/js/bootstrap-fileupload.min.css" />
<script src="//localhost/skymate/web/assets/js/bootstrap-fileupload.js"></script>
<link rel="stylesheet" href="//localhost/skymate/web/assets/css/jquery-ui.css">
<script src="//localhost/skymate/web/assets/css/jquery-ui.js"></script>




-->