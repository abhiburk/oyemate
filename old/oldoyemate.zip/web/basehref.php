<base href="http://www.oyemate.com/web/"/>
<!--<base href="//localhost/oyemate/web/"/>-->