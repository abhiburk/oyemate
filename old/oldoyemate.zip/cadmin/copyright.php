 <div class="copyrights">
	 <p>© 2017 clapdust . All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>